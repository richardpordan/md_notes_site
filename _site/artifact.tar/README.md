# Markdown Notes Site with Knowledge Graph

[![Deploy Jekyll site to Pages](https://github.com/richardpordan/md_notes_site/actions/workflows/jekyll.yml/badge.svg)](https://github.com/richardpordan/md_notes_site/actions/workflows/jekyll.yml)

[![Deployed site](https://badgen.net/static/Deployed%20site/LIVE/green)](https://richardpordan.github.io/md_notes_site/)

***In development***
